/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author aliya
 */
public class PaketFunRun {
    private String namaPaket;
    private double harga;
    private String fasilitas;

    public PaketFunRun(String namaPaket, double harga, String fasilitas) {
        this.namaPaket = namaPaket;
        this.harga = harga;
        this.fasilitas = fasilitas;
    }

    public String getNamaPaket() { return namaPaket; }
    public void setNamaPaket(String namaPaket) { this.namaPaket = namaPaket; }

    public double getHarga() { return harga; }
    public void setHarga(double harga) { this.harga = harga; }

    public String getFasilitas() { return fasilitas; }
    public void setFasilitas(String fasilitas) { this.fasilitas = fasilitas; }

    public void infoPaket() {
        System.out.println("Nama Paket : " + namaPaket);
        System.out.println("Harga      : Rp" + harga);
        System.out.println("Fasilitas  : " + fasilitas);
        System.out.println("---------------------------------");
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author aliya
 */
public class Panitia extends Person {
    private String divisi;

    public Panitia(String nama, String telepon, String email, String divisi) {
        super(nama, telepon, email);
        this.divisi = divisi;
    }

    public String getDivisi() { return divisi; }
    public void setDivisi(String divisi) { this.divisi = divisi; }

    @Override
    public void info() {
        System.out.println("======================================");
        infoDasar(); 
        System.out.println("Divisi Panitia: " + divisi);
        System.out.println("======================================");
    }
}
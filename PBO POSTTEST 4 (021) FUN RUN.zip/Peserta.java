/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author aliya
 */
public class Peserta extends Person implements Pembayaran {
    private PaketFunRun paket;
    private String metodeBayar;

    public Peserta(String nama, String telepon, String email, PaketFunRun paket, String metodeBayar) {
        super(nama, telepon, email);
        this.paket = paket;
        this.metodeBayar = metodeBayar;
    }

    @Override
    public void info() {
        System.out.println("======================================");
        infoDasar();
        System.out.println("Paket Dipilih : " + paket.getNamaPaket() + " (" + paket.getFasilitas() + ")");
        System.out.println("Metode Bayar  : " + metodeBayar);
        System.out.println("======================================");
    }

    @Override
    public void metodePembayaran() {
        System.out.println("Metode bayar: " + metodeBayar);
    }

    public void info(boolean lengkap) {
        if (lengkap) info();
        else System.out.println("Peserta: " + nama + " | Telepon: " + telepon +" | Email: " + email);
    }

    public PaketFunRun getPaket() { return paket; }
    public void setPaket(PaketFunRun paket) { this.paket = paket; }

    public String getMetodeBayar() { return metodeBayar; }
    public void setMetodeBayar(String metodeBayar) { this.metodeBayar = metodeBayar; }
}